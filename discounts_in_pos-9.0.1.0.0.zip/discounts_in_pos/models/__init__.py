# -*- coding: utf-8 -*-

import pos_order_lines_new
import pos_payment_report_new
import pos_lines_new
import pos_invoice_new
import pos_receipt_new
