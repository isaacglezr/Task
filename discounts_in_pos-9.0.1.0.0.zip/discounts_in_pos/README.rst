=================
Pos Discounts v19
=================

This module adds a feature to provide several types of discounts in point of sale.

Installation
============

Just select it from available modules to install it, there is no need to extra installations.

Configuration
=============

We need to specify a discount account when we create the point of sale. This account will be used to record the discount amount.

Credits
=======
Developer: Linto CT @ cybrosys, linto@cybrosys.in


