# -*- coding: utf-8 -*-

from . import pos_customer_display
